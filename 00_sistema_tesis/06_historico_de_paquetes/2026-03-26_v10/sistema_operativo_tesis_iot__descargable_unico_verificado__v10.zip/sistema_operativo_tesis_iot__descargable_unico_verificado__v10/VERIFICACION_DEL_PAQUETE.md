# Verificación del paquete

Este paquete fue verificado antes de su entrega.

## Controles realizados
1. Integridad del ZIP (`unzip -t`).
2. Listado completo de archivos internos.
3. Presencia del registro SQLite, contexto humano, contexto máquina, catálogo, evidencia y metadatos.
4. Archivo `SHA256SUMS.txt` generado para revalidación futura.

## Archivos mínimos esperados
- sistema_operativo_tesis_iot__archivo_de_contexto_canonico__lectura_humana__v09.md
- sistema_operativo_tesis_iot__archivo_de_contexto_canonico__lectura_maquina__v09.jsonl
- sistema_operativo_tesis_iot__registro_estructurado_del_contexto__v09.sqlite
- sistema_operativo_tesis_iot__catalogo_general_de_artefactos__v09.json
- sistema_operativo_tesis_iot__columna_vertebral_de_evidencia__v09.tsv

## Revalidación rápida
Ejecutar en la carpeta extraída:

```bash
sha256sum -c SHA256SUMS.txt
```
