# riesgos_y_controles.md

| Riesgo | Severidad | Control |
|---|---:|---|
| Acceso a terminal, archivos, credenciales, GitHub o red local | Alta | Permisos mínimos, sandboxing, listas de permiso y revisión humana. [REF:29da968c9c486b6378ff223aaa93c5f457fe04f9058006025150168407c8d8c4] |
| Sobredependencia de IA | Alta | Mantener juicio crítico del investigador y marco conceptual sólido. [REF:f02be52ef617b1e4fd93afcefed3a2bebb2924cc089e7ff92da31870791ef1d7] |
| Skills autónomas incorrectas | Media-alta | Versionar, probar y auditar cada skill antes de usarla en hardware real. [REF:bbbbeb545aa25b62dd59f6d2ad22fcb1dac479bd6982104af49ef585ca7d2865] |
| Carga excesiva en Orange Pi | Media | Mantener Orange Pi como nodo edge operativo y no como cerebro principal. [REF:1e238d6958b2ae01b9af613eac72f6843c22b2302f42c80dfcd67f9ac06e12bb] |
| Hallazgos no verificables | Alta | Mantener matriz de evidencia y no incorporar afirmaciones sin hash en el resumen. [REF:d41639b6aad9ff412d4cdae51fd45c0aaccb5f837336ae92d02cfe23af56b648] |
