# arquitectura_recomendada.md

```text
Tezkatli PC
│
├── OpenClaw Gateway
│   ├── Telegram / Matrix / WebChat
│   ├── MQTT Analyst
│   ├── Bitácora Experimental
│   ├── Hardware K’anek Agent
│   ├── LaTeX / BibTeX Agent
│   └── Seguridad IoT Agent
│
├── Modelos locales
│   ├── Qwen / Llama / Mistral
│   └── Hermes 3 8B cuantizado, si resulta estable
│
├── Hermes Agent opcional
│   ├── Investigación bibliográfica
│   ├── Skills reutilizables
│   └── Subagentes de análisis
│
└── Orange Pi 5 Plus
    ├── MQTT broker/bridge
    ├── Node-RED
    ├── servicios ligeros REST/WebSocket
    └── enlace con nodos LoRa
```

## Soporte literal

OpenClaw se recomienda como plano de control principal y Hermes como motor o agente auxiliar. [REF:fd8d753a5d22203ea75e6e040ba0330cb887bc7df6bba05c21de268d3e2f3bf4]

Tezkatli concentra inferencia principal, RAG, revisión bibliográfica, simulación, análisis de logs y generación de código; Orange Pi 5 Plus opera como nodo edge ligero. [REF:1e238d6958b2ae01b9af613eac72f6843c22b2302f42c80dfcd67f9ac06e12bb]

La arquitectura recomendada ubica OpenClaw Gateway en Tezkatli con agentes especializados y deja Orange Pi 5 Plus como nodo edge operativo. [REF:821d342f948f99863e876b1d351d0eeabefeb9685484d2daa8a2fef9aa3025e8]
