# PET OpenClaw–Hermes–Tesis IoT

Este paquete contiene una síntesis trazable del contexto trabajado sobre OpenClaw, Hermes y su posible uso en la tesis IoT.

## Archivos

- `contenido_literal.txt`: fragmentos literales con hash SHA-256.
- `resumen_de_investigacion.md`: síntesis con referencias `[REF:HASH]`.
- `matriz_evidencia.csv`: matriz de fragmentos y hashes.
- `arquitectura_recomendada.md`: arquitectura propuesta con soporte literal.
- `roadmap_mvp.md`: ruta mínima de implementación.
- `riesgos_y_controles.md`: riesgos técnicos y controles.
- `manifest.json`: metadatos del paquete.

## Regla de trazabilidad

Ninguna afirmación del resumen debe aceptarse si no cita un hash existente en `contenido_literal.txt`.

## Limitación

Este PET captura el contexto conversacional disponible; no sustituye revisión directa de documentación oficial, repositorios, artículos indexados ni experimentación propia. [REF:d41639b6aad9ff412d4cdae51fd45c0aaccb5f837336ae92d02cfe23af56b648]
