# roadmap_mvp.md

## MVP 1 — Base de investigación y evidencia

1. Implementar agente Estado del Arte IoT. [REF:30d3094fe436e2f4aa92161a4699c35baa48b5a95e449e5583cf967bc0bf39ce]  
2. Implementar verificador anti-alucinación y matriz de literatura. [REF:30d3094fe436e2f4aa92161a4699c35baa48b5a95e449e5583cf967bc0bf39ce]  
3. Implementar bitácora experimental. [REF:1420469d2f7a2e1acfe97aedfae83c02dc6235e2f8137f890cc66989bb284f54]

## MVP 2 — Laboratorio LoRa/MQTT

1. Implementar monitor de red LoRa. [REF:1420469d2f7a2e1acfe97aedfae83c02dc6235e2f8137f890cc66989bb284f54]  
2. Implementar analizador MQTT. [REF:1420469d2f7a2e1acfe97aedfae83c02dc6235e2f8137f890cc66989bb284f54]  
3. Registrar Packet Delivery Ratio, latencia, RSSI y SNR. [REF:45c5af3193a82e3ed601244a4696858f8ba963c0f2373e1ee78546c061d44eab]

## MVP 3 — Comparación OpenClaw/Hermes

1. Usar OpenClaw como plano de control principal. [REF:fd8d753a5d22203ea75e6e040ba0330cb887bc7df6bba05c21de268d3e2f3bf4]  
2. Probar Hermes Agent como complemento para tareas autónomas acotadas. [REF:bbbbeb545aa25b62dd59f6d2ad22fcb1dac479bd6982104af49ef585ca7d2865]  
3. Evaluar si Hermes como modelo local 8B cuantizado es estable en Tezkatli. [REF:65bfbe28b5c891fc0ceb440a30062b820d0a103d21be44e343867211bc9879fe]

## Primera prueba sugerida

Procesar logs LoRa y generar una skill reproducible para calcular Packet Delivery Ratio, latencia, RSSI y SNR. [REF:45c5af3193a82e3ed601244a4696858f8ba963c0f2373e1ee78546c061d44eab]
