# Resumen de investigación PET v2.2

## Tema
Harness Engineering para conmutación dinámica de modelos de inteligencia artificial, incluidos modelos locales y edge, aplicado a un sistema IoT LoRa P2P–MQTT con trazabilidad científica.

## Tesis técnica sintetizada
El harness engineering se plantea como una capa de orquestación que conecta contexto, modelos, herramientas, memoria y validadores mediante políticas explícitas [REF:914f96cbf601085ee5cd1583253f46f886ed423a695a3fdb5ebf5fbe021c16ad]. Su objetivo principal es seleccionar, descargar y ejecutar el modelo más adecuado —local, edge o nube— según tarea y contexto, conservando seguridad, confiabilidad, auditabilidad, verificabilidad y validabilidad [REF:4b870a5f72d9dafcf5220ea4945b949f50775dac77d4b36b2254a59e81d3e076].

## Justificación en IoT y LoRa
La arquitectura IoT propuesta requiere flexibilidad porque LoRaWAN de un solo salto no siempre resuelve cobertura, geografía compleja, comunicación P2P ni dependencia de nube en zonas con conectividad limitada [REF:6390742ea1ab5b208f486a24bde642b03f64c645369d19fdae005a0a4d56772d]. En redes LoRa mesh, la métrica Time on Air puede equilibrar el Packet Delivery Ratio entre nodos con distinta centralidad, lo que justifica evaluar métricas de ruteo y no sólo conectividad básica [REF:39727985cfa9577f020e82f54d541b26d5deb0a4d8735876bd19d0a75d25f032].

MQTT es pertinente como puente lógico porque permite entregar datos hacia lagos de datos para reporte, visualización, analítica avanzada y aprendizaje automático [REF:963d21e260481a6d89ad293eeefa3f2ff215edf42dab2a8a78af6ae709b8c76a]. Además, la literatura reporta que la retransmisión puede mejorar la probabilidad de entrega en MQTT sobre IoT cuando la red es poco confiable [REF:93e0c058fb23884bb38cbad662c301ef30e2b47b4cb353d4b3fb4ee6094ef8f2].

## Evidencia de despliegue y límites
El caso CityWAN muestra que LoRa puede desplegarse a escala urbana con 100 gateways y 19,821 nodos en 130 km² [REF:057161d42c89213e8dd458b1d3d15ee71ac460bf615640f4d13690a5257036cf], pero también muestra cuellos de botella urbanos por zonas ciegas y brechas entre eficiencia de gateway y cobertura [REF:b0f2ee4d90bb903f36936f09ff18dc8b00f12923b9c454d8a1c5f830d9b58057]. Por tanto, el proyecto debe incorporar medición empírica, no asumir que LoRa funciona de manera homogénea en Pachuca o en rutas urbanas.

La planeación de red depende de modelos de propagación precisos [REF:1e5338408a79d24f4467daf7b8f6e2e2f7ea4475ece3649ac866cf6ddfd06d2b]; sin embargo, los modelos empíricos pueden perder precisión fuera del entorno donde fueron medidos [REF:73098e30f47108ce4b34f4bf74c4d3b54e0c18a300a20030b97b4298e9ee126d]. Esto obliga a validar RSSI, SNR, Packet Delivery Ratio y pérdida de paquetes en campo antes de defender conclusiones generales.

## Pertinencia del edge computing local
La Orange Pi 5 Plus con RK3588 incluye CPU ARM octa-core y acelerador NPU de hasta 6 TOPS [REF:18ff8d5e81968c653b6619a842734c0b71e6399036ed2c1b2a5e04b80cbdb439], además de soporte para varios sistemas operativos como OpenWRT, Debian y Ubuntu [REF:e4c0afd5ffbb73f68e497b7a6cabd3f93ce07669c7cbff348dc0d55d4077c6c1]. Esto la vuelve candidata para gateway edge con inferencia local ligera, filtrado de eventos, broker MQTT y bitácora operativa, aunque no debe asumirse equivalente a una GPU de escritorio.

El gateway Heltec HT-M7603 declara soporte LoRaWAN y protocolos MQTT privados [REF:2d2d5f39ae536404c1ab075847de61b9b61523788cf96ca8331f4031ce447036], por lo que puede considerarse dentro de una arquitectura de pruebas, siempre que se validen sus límites reales de configuración, latencia, integración y seguridad.

## Gobernanza, seguridad y rigor
La IoT se describe como una tecnología de doble filo, con beneficios de automatización y optimización, pero también riesgos como vigilancia, dependencia y ciberataques [REF:e57fa67a55458053311ba571d0269c4811e4effc67c49a9b36b8ef3303c21f68]. Por ello, el harness debe incluir políticas de seguridad, privacidad, aislamiento, gestión de secretos, registro de evidencia y verificación cruzada.

Los estándares y el código abierto se consideran fundamentales para IoT [REF:16b38f8ec5022df02bfc285021d25eae4839da0996a72e6d625dc0072dd69943], lo cual respalda una estrategia basada en componentes auditables, formatos abiertos de bitácora y reproducibilidad metodológica. En una tesis de posgrado, la exigencia de rigurosidad, sistematicidad y originalidad es explícita [REF:bcf12f90be4a0a287d07b7df04412105e8a4109231a7f69155eecd5a4472ad7e], y el uso de IA debe potenciar, no sustituir, el juicio crítico del investigador [REF:eeb4e271400e7250abe851c1096b846ecbc951cb6254bf078b575d3af30ecc27].

## Regla de operación propuesta
La regla metodológica central queda definida así: ningún modelo decide solo, ninguna salida crítica queda sin evidencia y ninguna evidencia queda sin trazabilidad [REF:26c58ccc2e8c4852823b2c89341b7bf268334884954072330ac4980ab3eaa63e]. Para tareas con datos sensibles, se propone procesar primero en local o edge [REF:31c049d22d043bd48d1c0e743b72990b08991988de2b4867d4253aef5454400f]. La evaluación del sistema debe medir latencia p50/p95, tokens por segundo, Packet Delivery Ratio, RSSI/SNR, fugas de datos y porcentaje de trazabilidad [REF:a0e570fc2cbe89231a5b60f8ccfb2927954a62f3d0db57b4639ccde07a80c11a].

## Variables sugeridas

| Tipo | Variable | Operacionalización mínima |
|---|---|---|
| Independiente | Política de selección de modelo | local / edge / nube / ensamble; umbral de riesgo; umbral de latencia; sensibilidad de datos |
| Independiente | Complejidad de tarea | clasificación, extracción, razonamiento, verificación documental, generación de código |
| Dependiente | Confiabilidad de salida | tasa de aceptación por verificación, contradicciones detectadas, éxito de fallback |
| Dependiente | Auditabilidad | porcentaje de ejecuciones con modelo, versión, prompt, hash, fuente y métrica registrados |
| Dependiente | Desempeño operativo | latencia, consumo energético, tokens/s, costo por inferencia |
| Dependiente IoT | Calidad de red | RSSI, SNR, PDR, pérdida de paquetes, tiempo de ida y vuelta MQTT |
| Control | Hardware | PC local, Orange Pi 5 Plus RK3588, gateway LoRa, nodos Heltec |

## Riesgos y límites
- Las fuentes de IA marcadas como `AUTORIDAD: IA` son propuestas conceptuales y deben validarse experimentalmente antes de incorporarse como resultados.
- Los fragmentos documentales son evidencia textual, pero no sustituyen la lectura completa de cada artículo o manual.
- La infografía generada puede contener texto visual no perfecto por limitaciones de generación de imagen; debe usarse como material conceptual, no como documento final de tesis sin revisión.
- El desempeño real de modelos locales en PC y Orange Pi debe medirse con benchmarks propios bajo las restricciones reales de memoria, temperatura y energía.

## Recomendación metodológica inmediata
Construir un experimento mínimo viable: 3 modelos locales/edge/nube × 5 tareas de tesis × 3 niveles de sensibilidad de datos. Para cada ejecución registrar hash de entrada, modelo, versión, parámetros, latencia, costo, salida, verificador, fuentes y decisión final.
