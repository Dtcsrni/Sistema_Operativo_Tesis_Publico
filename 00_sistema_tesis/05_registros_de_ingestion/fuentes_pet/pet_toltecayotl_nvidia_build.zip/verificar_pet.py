#!/usr/bin/env python3
from pathlib import Path
import re, hashlib, sys
base = Path(__file__).resolve().parent
literal = (base / "contenido_literal.txt").read_text(encoding="utf-8")
summary = (base / "resumen_de_investigacion.md").read_text(encoding="utf-8")
blocks = re.findall(r"\[(F\d+)\]\nsha256=([0-9a-f]{64})\nliteral=<<<\n(.*?)\n>>>", literal, re.S)
if not blocks:
    print("ERROR: no se encontraron fragmentos.")
    sys.exit(1)
known = {}
for fid, declared, text in blocks:
    actual = hashlib.sha256(text.encode("utf-8")).hexdigest()
    if actual != declared:
        print(f"ERROR: hash inválido en {fid}: declarado={declared} actual={actual}")
        sys.exit(1)
    known[declared] = fid
refs = re.findall(r"\[REF:([0-9a-f]{64})\]", summary)
missing = [r for r in refs if r not in known]
if missing:
    print("ERROR: referencias no declaradas:")
    for m in missing:
        print(m)
    sys.exit(1)
violations = []
for i, line in enumerate(summary.splitlines(), start=1):
    s = line.strip()
    if not s or s.startswith("#"):
        continue
    if not re.search(r"\[REF:[0-9a-f]{64}\]", s):
        violations.append((i, s))
if violations:
    print("ADVERTENCIA: líneas sin REF:")
    for i, s in violations:
        print(f"{i}: {s}")
    sys.exit(2)
print(f"OK: {len(blocks)} fragmentos con SHA-256 válido y {len(refs)} referencias cruzadas verificadas.")
