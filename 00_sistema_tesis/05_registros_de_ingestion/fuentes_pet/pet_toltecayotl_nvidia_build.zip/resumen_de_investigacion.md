# resumen_de_investigacion.md — Síntesis PET blindada

## Alcance

La sesión analizada partió del enlace `https://build.nvidia.com/models`. [REF:7a1f0fad5f727ae3da6ad490ac0d7325d05e3ebb769a09f949bb671e2362f60c]

El enlace fue caracterizado como el catálogo NVIDIA Build / NVIDIA NIM, orientado a probar, comparar y desplegar modelos de inteligencia artificial mediante APIs o microservicios optimizados para GPU NVIDIA. [REF:7f12b76b0eca3796855a30af439ea09f18cb055e8eaa000b211182b44b0e8a54]

## Hallazgos verificables

1. NVIDIA Build / NIM fue descrito como una plataforma asociada al despliegue y escalamiento de modelos en infraestructura GPU mediante NVIDIA NIM inference microservices. [REF:68f5019dec4176ef83f2d767806ff250f3f9c540e2644bb3182c39a916f164bb]

2. En la sesión se registró que el catálogo mostraba 158 modelos y filtros como Free Endpoint, Download Available, Retrieval Augmented Generation, Code Generation, Image-to-Text y Speech-to-Text. [REF:68f5019dec4176ef83f2d767806ff250f3f9c540e2644bb3182c39a916f164bb]

3. La sesión identificó modelos recientes o pesados dentro del catálogo, incluyendo ejemplos como `mistral-medium-3.5-128b`, `deepseek-v4-flash`, `deepseek-v4-pro`, `nemotron-3-nano-omni-30b-a3b-reasoning`, `llama-nemotron-rerank-1b-v2`, `nemotron-ocr-v1` y `qwen3.5-122b-a10b`. [REF:feebf52da362eec9fbbd8b28a6b490568cb2bbf7145df2f33e7d0fed9f381b1f] [REF:23eedc418585516d3048d88677444c23b49276ccc3b0ccb7e096e8b679731a42]

4. La sesión sostuvo que las APIs de NVIDIA incluyen NIM y microservicios CUDA-X, y que pueden utilizarse endpoints cloud para prototipado. [REF:133cdffc84fb98ec70f1bc8672564d2e938c20a2e6d768c8d43646dba29adc55]

5. Para el caso del usuario, la sesión concluyó que NVIDIA Build / NIM no sustituye directamente a Ollama local, pero puede operar como capa externa de validación y benchmarking. [REF:3a9ead2097c7d76d4aaa0ec4305e2ca97974861834258b6d12b69d0e284415e1]

6. La sesión recomendó NVIDIA Build para probar modelos grandes, RAG para tesis, OCR de PDFs técnicos y comparación de capacidades de código. [REF:192886b505dbd720369172afc319f5db24a1ac5c5688526f0cf6ad5bf62f853c]

7. La sesión no recomendó asumir ejecución completamente offline ni uso directo en Orange Pi 5 Plus, porque se indicó que muchos modelos son endpoints cloud o requieren GPU grande, y que NIM está orientado a GPUs NVIDIA mientras la Orange Pi usa RK3588/RKNN. [REF:192886b505dbd720369172afc319f5db24a1ac5c5688526f0cf6ad5bf62f853c]

8. La sesión distinguió dos modalidades de uso de NIM: endpoint cloud desde build.nvidia.com y contenedor NIM descargable/self-hosted. [REF:95d81430100fbebfb2151a1dee0ced7d6ac6fee6e6f88e0ae67950e56d8595fa]

9. La sesión describió NIM como microservicios preconstruidos y optimizados para infraestructura acelerada por NVIDIA, incluyendo nube, centro de datos, workstation y edge. [REF:c71c5a82c8cb7fbfdc67ec59a4efd5fd9b6bed4ff2aa2e69375fa71b48282013]

10. La sesión indicó que la RTX 4060 Ti de 8 GB es útil para IA local, pero no para la mayoría de modelos grandes del catálogo NIM. [REF:6b728931d2fe2d0422e25f91db0dc76b5c8ae3e67ce76a3344f0a64ce64a2969]

11. La sesión incorporó una heurística de memoria para pesos de modelo basada en parámetros totales, bytes por parámetro y tensor parallelism. [REF:bb2ef265d58f442485c60d6ee5f513de3801e25cdf45ab34b79b36a8f86cd52a]

12. La sesión registró como referencia que Llama 3.1 8B en BF16 requiere aproximadamente 16 GB solo para pesos y que una GPU de 24 GB ofrece espacio adicional para KV cache y overhead. [REF:ae9866a3c717ff9e19d408ce9347647ce04d8e43423907977668d4af6caaf7a9]

13. La sesión clasificó como alta la viabilidad local de modelos 1B–4B cuantizados y 7B–8B cuantizados INT4/GGUF con Ollama/llama.cpp. [REF:b7ea1b63ec83b969b6822a60ec72fdccaaf85d6f4e7db26bd4657ed0e49ff25a]

14. La sesión clasificó como baja o no realista la ejecución local de 8B BF16/FP16 en NIM, 30B+, 70B+ y 120B–480B MoE en la RTX 4060 Ti de 8 GB. [REF:b7ea1b63ec83b969b6822a60ec72fdccaaf85d6f4e7db26bd4657ed0e49ff25a]

15. La arquitectura recomendada para Tezkatli separó tres capas: local rápido, NVIDIA Build / NIM y Edge Orange Pi 5 Plus. [REF:d8dc52be03ec7003a9659cf0bd20611a9c1e72c6f7d642d32fbcb330ba2ddeab] [REF:4571bc24d90ed43c0c69d62c0e7e958c791c1405da534adae77c3434d9c51659]

16. La capa local rápida fue asociada con Ollama / llama.cpp, Qwen 7B / Llama 8B cuantizados, embeddings locales y RAG privado con PDFs. [REF:4571bc24d90ed43c0c69d62c0e7e958c791c1405da534adae77c3434d9c51659]

17. La capa NVIDIA Build / NIM fue asociada con benchmark contra modelos grandes, OCR técnico, reranking externo, validación cruzada y modelos multimodales pesados. [REF:4571bc24d90ed43c0c69d62c0e7e958c791c1405da534adae77c3434d9c51659]

18. La capa Edge Orange Pi 5 Plus fue asociada con inferencia ligera RKNN/RKLLM, gateway IoT, clasificación básica/eventos y no usar NIM directamente. [REF:4571bc24d90ed43c0c69d62c0e7e958c791c1405da534adae77c3434d9c51659]

19. El veredicto de la sesión fue explorar NVIDIA Build como banco de pruebas y capa de referencia externa para modelos grandes, no como base principal del stack local edge. [REF:d1cca87d89a8bcb2b0fcb5f1296d8ef4f9c4a6ab83c4c70b2bf1c325a74cefd1]

20. Para la tesis, la sesión propuso usar NVIDIA Build para comparar modelos locales contra modelos cloud de alto desempeño, medir calidad en RAG científico, validar extracción desde PDFs técnicos, evaluar reranking y documentar una arquitectura híbrida local–cloud–edge. [REF:371209409caff5651036ecc8cfd04f733ef66b5a41998fd4964e1f7dc891d387]

21. La prueba práctica propuesta consistió en seleccionar tres tareas medibles: resumen de paper, extracción de parámetros técnicos y generación de hipótesis/variables, comparando Ollama local, NVIDIA endpoint y ChatGPT mediante una rúbrica cuantitativa. [REF:a1ae81e1c5ef0fb5da4c921a4d6c191ee50c241668f9aaef4f8583d0b9a0774f]

## Límites epistémicos

Esta síntesis no agrega afirmaciones externas a los fragmentos literales incluidos en `contenido_literal.txt`. [REF:7a1f0fad5f727ae3da6ad490ac0d7325d05e3ebb769a09f949bb671e2362f60c] [REF:7f12b76b0eca3796855a30af439ea09f18cb055e8eaa000b211182b44b0e8a54] [REF:68f5019dec4176ef83f2d767806ff250f3f9c540e2644bb3182c39a916f164bb] [REF:feebf52da362eec9fbbd8b28a6b490568cb2bbf7145df2f33e7d0fed9f381b1f] [REF:23eedc418585516d3048d88677444c23b49276ccc3b0ccb7e096e8b679731a42] [REF:133cdffc84fb98ec70f1bc8672564d2e938c20a2e6d768c8d43646dba29adc55] [REF:3a9ead2097c7d76d4aaa0ec4305e2ca97974861834258b6d12b69d0e284415e1] [REF:192886b505dbd720369172afc319f5db24a1ac5c5688526f0cf6ad5bf62f853c] [REF:95d81430100fbebfb2151a1dee0ced7d6ac6fee6e6f88e0ae67950e56d8595fa] [REF:c71c5a82c8cb7fbfdc67ec59a4efd5fd9b6bed4ff2aa2e69375fa71b48282013] [REF:6b728931d2fe2d0422e25f91db0dc76b5c8ae3e67ce76a3344f0a64ce64a2969] [REF:bb2ef265d58f442485c60d6ee5f513de3801e25cdf45ab34b79b36a8f86cd52a] [REF:ae9866a3c717ff9e19d408ce9347647ce04d8e43423907977668d4af6caaf7a9] [REF:b7ea1b63ec83b969b6822a60ec72fdccaaf85d6f4e7db26bd4657ed0e49ff25a] [REF:d8dc52be03ec7003a9659cf0bd20611a9c1e72c6f7d642d32fbcb330ba2ddeab] [REF:4571bc24d90ed43c0c69d62c0e7e958c791c1405da534adae77c3434d9c51659] [REF:d1cca87d89a8bcb2b0fcb5f1296d8ef4f9c4a6ab83c4c70b2bf1c325a74cefd1] [REF:371209409caff5651036ecc8cfd04f733ef66b5a41998fd4964e1f7dc891d387] [REF:a1ae81e1c5ef0fb5da4c921a4d6c191ee50c241668f9aaef4f8583d0b9a0774f]
