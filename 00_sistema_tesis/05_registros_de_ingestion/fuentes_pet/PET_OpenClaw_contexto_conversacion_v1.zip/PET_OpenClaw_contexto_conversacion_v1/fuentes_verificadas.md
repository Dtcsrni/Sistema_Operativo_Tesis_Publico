# Fuentes externas verificadas

Las fuentes siguientes se usaron únicamente para validar conceptos externos al diálogo. Las decisiones de alcance del proyecto provienen de los fragmentos literales del tesista.

1. Goodfire — The World Inside Neural Networks  
   URL: https://www.goodfire.ai/research/the-world-inside-neural-networks  
   Fragmento PET: F100 / 62694f96700f1bf7af4eca70cf81280ffe181518c891ef2f52a01caa32eb4bb7

2. Wurgaft et al. — Manifold Steering Reveals the Shared Geometry of Neural Network Representation and Behavior  
   URL: https://arxiv.org/abs/2605.05115  
   Fragmento PET: F101 / 1b97c9612f192a9ff081a06b3ef35948c66518e096b8bc51ecb2967c14dd9e75

3. Dhuliawala et al. — Chain-of-Verification Reduces Hallucination in Large Language Models  
   URL: https://arxiv.org/abs/2309.11495  
   Fragmento PET: F102 / 44e0b3f8f2226708c3eb0ab26c3ccfa962791f94a2e8709de6eaca04cf28f47b

4. Asai et al. — Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection  
   URL: https://arxiv.org/abs/2310.11511  
   Fragmento PET: F103 / 552286c41749973f59ed9b8a57115a8fa12e395ea89cd132ef5822671cfabaf2

5. Es et al. — Ragas: Automated Evaluation of Retrieval Augmented Generation  
   URL: https://arxiv.org/abs/2309.15217  
   Fragmento PET: F104 / 8f16cf4d2ab623a07f394090b64dbb5b687c3ca27283fc34c1f0df2078b5a97b

6. Getu et al. — A Survey on Goal-Oriented Semantic Communication  
   URL: https://espace2.etsmtl.ca/id/eprint/28578/1/Kaddoum-G-2024-28578.pdf  
   Fragmento PET: F105 / 3ab715edf35d9b29e74345de6e90751db3765dc1a5db91daee5826b772095786

7. Wong et al. — Multi-Hop and Mesh for LoRa Networks  
   URL: https://dl.acm.org/doi/10.1145/3638241  
   Fragmento PET: F106 / a48c33c06017eee3d900cb069dd192424654ad456bb301b03c34f363fec68b28

8. Tong et al. — Citywide LoRa Network Deployment and Operation  
   URL: https://dl.acm.org/doi/10.1145/3625687.3625796  
   Fragmento PET: F107 / 69d3baa3bed287f4572d42904d2baa93e161497096936a17ae7d3980b9c2a2cb

9. Heltec — HT-M7603 Indoor LoRa Gateway  
   URL: https://heltec.org/project/ht-m7603/  
   Fragmento PET: F108 / f93e518d9d3dbe90bdac9dbfb5ca61b2e51a38b9b720c17458c8b5d9f9a4c73b

10. Orange Pi — Orange Pi 5 Plus  
    URL: https://www.orangepi.org/html/hardWare/computerAndMicrocontrollers/details/Orange-Pi-5-plus.html  
    Fragmento PET: F109 / 520afc873d53a251002f88177f10005cab85b9602dda92a5c3c3e600fb47ba4c
