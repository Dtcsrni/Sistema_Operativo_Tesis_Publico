# Paquete PET — OpenClaw / Tesis IoT / Contexto conversacional

Este paquete contiene:

- `contenido_literal.txt`: fragmentos atómicos con hash SHA-256.
- `contenido_literal.jsonl`: versión estructurada para procesamiento.
- `resumen_de_investigacion.md`: síntesis donde cada afirmación se referencia con `[REF:HASH]`.
- `matriz_validacion.csv`: matriz de afirmaciones y soporte.
- `fuentes_verificadas.md`: fuentes externas usadas para validar conceptos.
- `cronologia_contextual.md`: secuencia contextual de la conversación.

## Advertencia de alcance

Los fragmentos marcados como `Tesista` provienen de mensajes textuales del usuario.  
Los fragmentos marcados como `IA` son propuestas/síntesis generadas durante la conversación.  
Los fragmentos marcados como `Documento_Externo` o `Hardware_Spec` fueron verificados con fuentes web durante la generación del paquete.

## Integridad

Cada `HASH_SHA256` fue calculado únicamente sobre el campo `TEXTO_LITERAL`, codificado en UTF-8.

## Limitación

Los mensajes de audio no se incluyeron como transcripción literal porque no hubo texto accesible del audio en el historial; solo se integró el contexto resultante de las respuestas y mensajes textuales.
