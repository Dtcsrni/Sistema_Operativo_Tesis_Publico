# Resumen de investigación PET — contexto de conversación OpenClaw/tesis IoT

**Fecha de generación:** 2026-05-22  
**Alcance:** síntesis verificable del contexto conversacional disponible en esta sesión.  
**Limitación explícita:** los turnos enviados como audio aparecen en el historial como `AudioDisplayed`, sin transcripción literal accesible en este entorno; por tanto, se conservaron como contexto indirecto únicamente a través de las respuestas generadas y de los mensajes textuales posteriores.

## 1. Eje conceptual inicial

La conversación inició a partir del enlace de Goodfire sobre geometría interna de redes neuronales [REF:8f82b537bc15d692918394c12605a3ef496d61e963ba9094068d36c768cb2eab]. El punto técnicamente útil para el proyecto fue distinguir entre búsqueda vectorial, representaciones internas de modelos y control semántico del agente [REF:cd1f2bb7304bb204549667aa5ac964d67285098c709c7d29351e79f8a115d3e3]. La idea externa verificada que sustenta esta discusión es que un concepto puede vivir en una variedad curva y no necesariamente sobre una línea recta [REF:62694f96700f1bf7af4eca70cf81280ffe181518c891ef2f52a01caa32eb4bb7]. El trabajo relacionado de manifold steering plantea que el problema de steering pasa de buscar una dirección correcta a buscar la geometría correcta [REF:1b97c9612f192a9ff081a06b3ef35948c66518e096b8bc51ecb2967c14dd9e75].

## 2. Corrección del enfoque sobre Weaviate/OpenClaw

A solicitud del tesista, se profundizó la respuesta anterior [REF:406a7b044dba4163d64068124bc3cb5addd3dc38afa26b85bb9dd70aec396199]. El criterio consolidado fue que Weaviate debe entenderse como un mecanismo de cercanía semántica, mientras que OpenClaw debe demostrar pertinencia, evidencia y coherencia [REF:4994b0554baf1d77afbb3a14e9bbfebfd065866a5ebee17ae261418fb5831b90]. Esta distinción evita confundir recuperación vectorial con validez epistemológica.

## 3. Minimización de alucinaciones y ambigüedades

El usuario solicitó una estrategia más amplia para reducir alucinaciones y ambigüedades [REF:d5b981a2e14fbbda9909c9de533ce087d96f13b76e2120017884e36e0fc698d4]. La respuesta consolidada fue que no basta con mejorar prompts; se requiere una arquitectura que distinga fuente recuperada, inferencia razonable, supuesto, incertidumbre y abstención [REF:e9d1c32e7141c4fce268272826181cfc56ddbba64a1054ceed8ffc55967f7604]. La necesidad de este control queda apoyada por literatura que reconoce que la generación plausible pero incorrecta sigue siendo un problema abierto [REF:44e0b3f8f2226708c3eb0ab26c3ccfa962791f94a2e8709de6eaca04cf28f47b]. Self-RAG respalda el uso de recuperación y autorreflexión para mejorar calidad y factualidad [REF:552286c41749973f59ed9b8a57115a8fa12e395ea89cd132ef5822671cfabaf2], mientras que Ragas proporciona un marco de evaluación de pipelines Retrieval-Augmented Generation [REF:8f16cf4d2ab623a07f394090b64dbb5b687c3ca27283fc34c1f0df2078b5a97b].

## 4. División en casos de uso

El usuario pidió separar la infraestructura en contextos o casos de uso [REF:75170e8f370c25ad0d163b2ad33027c641b2867fc361f75d0e60e9225a3b31bf]. La primera clasificación distinguió cargas por nivel: PC/GPU para razonamiento y análisis pesado, Orange Pi para edge gateway y monitoreo, nodos Heltec/K’anek A1 para sensado y telemetría compacta, y LoRa/MQTT para transporte de eventos y datos [REF:8b497e3417c785ea1e0c9ea05e0f5c4a97d5448ec9bceafa3269f61531f7b96b].

## 5. Delimitación crítica hecha por el tesista

La delimitación más importante fue establecida por el usuario: el antiguo “auditor epistémico” debe reformularse como asistente agéntico de tesis y no formar parte directa de la investigación; el copiloto de experimentos debe incluir diseño, conexiones, soldadura, montaje y hardware; el optimizador LoRa P2P/mesh es la función más importante del stack de IA; el análisis de datos debe ser confiable pero subordinado a IoT; y la transferencia tecnológica/demos no es conveniente como prioridad [REF:c6de66fa52b9c67f1ebfd46a32a73276b80c67eb52a6cb91cee397202f01b6b3].

## 6. Reencuadre metodológico

El reencuadre aceptado fue que la tesis no debe convertirse en tesis de IA, sino en tesis de Internet de las Cosas donde la IA funcione como herramienta metodológica, asistente técnico, capa auxiliar de análisis/optimización y soporte experimental [REF:dabe7cc69ea43b32c5bde109143b0e985de25d9d24773a2e82118f6765ee3b66]. El antecedente externo sobre LoRa multi-hop/mesh queda ubicado como fuente pertinente para el núcleo de red [REF:a48c33c06017eee3d900cb069dd192424654ad456bb301b03c34f363fec68b28]. CityWAN se conserva como antecedente de despliegue urbano LoRa a gran escala [REF:69d3baa3bed287f4572d42904d2baa93e161497096936a17ae7d3980b9c2a2cb].

## 7. Inteligencia distribuida en nodos

El usuario añadió que todos los nodos deberán poder ser autónomos e inteligentes, aplicando IA según convenga a cada caso de uso [REF:9010cd150b9cb4b367f73dde0ae469cdd46a261b84f3916438e8ae0a0d75fd06]. La síntesis técnica resultante fue abandonar el modelo de un solo cerebro central y adoptar una arquitectura de inteligencia distribuida proporcional a función, energía, cómputo y criticidad operativa de cada nodo [REF:bdfa315002fe6e769c3b09c13dbc6fb276c2465972882e55356eacfd0949545b]. En esta arquitectura, el hardware HT-M7603 se mantiene como opción de gateway LoRaWAN/custom MQTT [REF:f93e518d9d3dbe90bdac9dbfb5ca61b2e51a38b9b720c17458c8b5d9f9a4c73b], mientras Orange Pi 5 Plus se ubica como nodo edge de mayor capacidad por su procesador RK3588 [REF:520afc873d53a251002f88177f10005cab85b9602dda92a5c3c3e600fb47ba4c].

## 8. Comunicación semántica como optimización de red

El usuario preguntó si parte de los roles de los nodos podría ser optimizar la red mediante comunicación semántica [REF:bb21e71b3846f301548218fdb49cb4f587d065512b2081c85338530ffeae91a1]. La respuesta consolidada fue que sí, siempre que se formule como comunicación semántica ligera orientada a tarea: transmisión de evento, prioridad, confianza, urgencia y contexto en lugar de datos crudos indiscriminados [REF:61276aaf4dda500ca13e03009ab2f566fdd61290e94778be3f8073385926131f]. La literatura de comunicación semántica orientada a objetivo respalda la transmisión de información semánticamente relevante para la ejecución efectiva de acciones [REF:3ab715edf35d9b29e74345de6e90751db3765dc1a5db91daee5826b772095786].

## 9. Formulación consolidada

La formulación integrada del proyecto, derivada de los fragmentos anteriores, es:

> Diseño y validación experimental de una arquitectura IoT basada en LoRa P2P/mesh y MQTT edge, con inteligencia distribuida por niveles y comunicación semántica ligera orientada a tarea, para optimizar confiabilidad, consumo energético, priorización de eventos y continuidad operativa. [REF:c6de66fa52b9c67f1ebfd46a32a73276b80c67eb52a6cb91cee397202f01b6b3] [REF:dabe7cc69ea43b32c5bde109143b0e985de25d9d24773a2e82118f6765ee3b66] [REF:9010cd150b9cb4b367f73dde0ae469cdd46a261b84f3916438e8ae0a0d75fd06] [REF:bdfa315002fe6e769c3b09c13dbc6fb276c2465972882e55356eacfd0949545b] [REF:61276aaf4dda500ca13e03009ab2f566fdd61290e94778be3f8073385926131f]

## 10. Clasificación final de componentes

| Componente | Clasificación | Estado en la tesis |
|---|---|---|
| Optimizador LoRa P2P/mesh | Núcleo de investigación | Central |
| Supervisión LoRa/MQTT/edge | Sistema experimental integrado | Central/secundario |
| Copiloto de experimentos y hardware | Soporte técnico-experimental | Integrado, no protagonista |
| Analizador de datos experimentales | Validación cuantitativa | Subordinado a IoT |
| Asistente agéntico de tesis | Herramienta metodológica personal | Fuera del objeto de investigación |
| Asistente de campo/aprovisionamiento | Subfunción de experimentos/hardware | Soporte |
| Gobernanza de código/repositorio | Herramienta interna | Fuera del objeto de investigación |
| Transferencia tecnológica/demos | Descartado por ahora | No prioritario |

## 11. Estado de validación

Este paquete distingue tres niveles de evidencia:  
1. **Literal del tesista:** decisiones y delimitaciones expresadas por el usuario [REF:c6de66fa52b9c67f1ebfd46a32a73276b80c67eb52a6cb91cee397202f01b6b3] [REF:9010cd150b9cb4b367f73dde0ae469cdd46a261b84f3916438e8ae0a0d75fd06] [REF:bb21e71b3846f301548218fdb49cb4f587d065512b2081c85338530ffeae91a1].  
2. **Propuesta IA:** síntesis y arquitectura derivada de la conversación [REF:dabe7cc69ea43b32c5bde109143b0e985de25d9d24773a2e82118f6765ee3b66] [REF:bdfa315002fe6e769c3b09c13dbc6fb276c2465972882e55356eacfd0949545b] [REF:61276aaf4dda500ca13e03009ab2f566fdd61290e94778be3f8073385926131f].  
3. **Documento externo/hardware verificado:** fuentes web y académicas usadas para sostener conceptos no originados en la conversación [REF:62694f96700f1bf7af4eca70cf81280ffe181518c891ef2f52a01caa32eb4bb7] [REF:1b97c9612f192a9ff081a06b3ef35948c66518e096b8bc51ecb2967c14dd9e75] [REF:44e0b3f8f2226708c3eb0ab26c3ccfa962791f94a2e8709de6eaca04cf28f47b] [REF:552286c41749973f59ed9b8a57115a8fa12e395ea89cd132ef5822671cfabaf2] [REF:8f16cf4d2ab623a07f394090b64dbb5b687c3ca27283fc34c1f0df2078b5a97b] [REF:3ab715edf35d9b29e74345de6e90751db3765dc1a5db91daee5826b772095786] [REF:a48c33c06017eee3d900cb069dd192424654ad456bb301b03c34f363fec68b28] [REF:69d3baa3bed287f4572d42904d2baa93e161497096936a17ae7d3980b9c2a2cb] [REF:f93e518d9d3dbe90bdac9dbfb5ca61b2e51a38b9b720c17458c8b5d9f9a4c73b] [REF:520afc873d53a251002f88177f10005cab85b9602dda92a5c3c3e600fb47ba4c].

## 12. Riesgos pendientes

- La comunicación semántica ligera debe operacionalizarse con códigos de evento, prioridad, confianza y vigencia temporal antes de afirmarla como mejora experimental [REF:61276aaf4dda500ca13e03009ab2f566fdd61290e94778be3f8073385926131f].
- El optimizador LoRa P2P/mesh requiere métricas experimentales propias: Packet Delivery Ratio, Received Signal Strength Indicator, Signal-to-Noise Ratio, latencia, consumo energético, retransmisiones y tiempo en aire [REF:c6de66fa52b9c67f1ebfd46a32a73276b80c67eb52a6cb91cee397202f01b6b3].
- La IA debe mantenerse como soporte del sistema IoT; no debe desplazar el objeto de investigación hacia inteligencia artificial general [REF:dabe7cc69ea43b32c5bde109143b0e985de25d9d24773a2e82118f6765ee3b66].

## 13. Próxima acción recomendada

Convertir esta síntesis en una matriz formal de requisitos, variables, hipótesis y módulos experimentales. Esa matriz debe separar: núcleo de tesis, sistema experimental, herramientas personales y elementos descartados o postergados [REF:c6de66fa52b9c67f1ebfd46a32a73276b80c67eb52a6cb91cee397202f01b6b3] [REF:dabe7cc69ea43b32c5bde109143b0e985de25d9d24773a2e82118f6765ee3b66].
