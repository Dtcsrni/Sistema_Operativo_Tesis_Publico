# Paquete Epistémico Toltecayotl (PET)
## OpenClaw local-first, evaluación de modelos locales y operación con Codex

**PET ID:** PET-OPENCLAW-LOCALFIRST-20260501-001  
**Fecha de síntesis:** 2026-05-01  
**Proyecto:** Sistema Operativo de Tesis Posgrado IoT / Toltecayotl  
**Modelo sintetizador:** GPT-5.5 Thinking  
**Propósito:** registrar conocimiento técnico de la sesión para mejorar el Sistema Operativo de Tesis, especialmente OpenClaw, Serena MCP, Ollama local, modelos locales y flujo controlado con Codex.

---

## 1. Tesis técnica de la sesión

La sesión demostró que el carril más viable para el sistema actual no es automatizar ChatGPT vía navegador, sino consolidar un flujo **local-first**:

```text
OpenClaw = plano de control asistivo local-first
Serena MCP = contexto + recuperación compacta + gobernanza/preflight
Ollama / llama.cpp = inferencia local
Codex = ejecutor controlado de cambios bajo tickets
Tesista = gate humano y autoridad metodológica final
```

La arquitectura resultante debe evitar que modelos locales o agentes externos escriban directamente al canon. Toda mutación relevante debe pasar por **ticket, preflight, validación, auditoría y aprobación humana**.

---

## 2. Evidencia técnica observada

### 2.1 ChatGPT web assisted

Se intentó habilitar `chatgpt_plus_web_session` con Playwright. La configuración llegó a estado local correcto:

```json
{
  "provider": "chatgpt_plus_web_session",
  "playwright": "ok",
  "headless": false,
  "gui_session_available": true
}
```

Sin embargo, el navegador controlado por Playwright fue detectado por el flujo anti-automatización del sitio. La sesión derivó hacia `chatgpt.com/api/auth/error`. Conclusión: **no conviene depender de ChatGPT web assisted como infraestructura de tesis**. Debe quedar experimental o manual supervisado.

### 2.2 Ollama local

PowerShell no encontró el ejecutable `ollama`, pero la API local sí respondió en:

```text
http://127.0.0.1:11434/api/tags
```

Conclusión: **Ollama funciona por API aunque el CLI no esté en PATH**. OpenClaw puede consumir la API local sin depender del binario `ollama`.

Modelos locales observados:

```text
hermes3:3b
hermes3:8b
qwen3:4b
phi4:14b
qwen3:14b
qwen2.5-coder:14b
gemma3:12b
mistral-nemo:12b
llama3.1:8b
qwen2.5:0.5b
qwen2.5:7b-instruct
```

---

## 3. Evaluación de modelos locales

### 3.1 `hermes3:8b`

Primera prueba con `/api/generate` y sin prompt de sistema: **rechazada**.

Problemas:
- tono informal;
- metáforas culturales;
- definió OpenClaw como librería genérica;
- inventó paralelismo de datos;
- no respetó el contexto de tesis.

Segunda prueba con `/api/chat` y prompt de sistema: **mejoró**, pero quedó condicionado.

Problemas remanentes:
- describió Serena MCP y Codex como “sistemas de control de versiones y gestión de proyectos”, lo cual es incorrecto;
- útil para borradores, no para canon ni decisiones.

Uso recomendado:
```text
hermes3:8b → borradores técnicos internos y síntesis moderada, siempre con prompt restrictivo.
```

### 3.2 `qwen2.5:7b-instruct`

Primera prueba: **rechazada para uso canónico**.

Problemas:
- inventó planificación de horarios;
- inventó canal con comité asesor;
- afirmó “aprobaciones automatizadas”, contrario al gate humano.

Segunda prueba con prompt restrictivo: **mejoró**.

Problemas remanentes:
- dijo que OpenClaw permite edición/ejecución de código, cuando lo correcto es que coordina tareas/tickets y Codex ejecuta bajo control;
- sobregeneralizó consistencia y actualización.

Uso recomendado:
```text
qwen2.5:7b-instruct → comandos rápidos, checklists, Telegram y respuestas simples.
```

### 3.3 `mistral-nemo:12b`

Prueba con prompt restrictivo: **aprobado como modelo académico local principal**, con advertencia de latencia.

Métricas observadas:
```text
Duración total: 100.172 s
Carga modelo: 58.635 s
Generación: 31.435 s
Tokens generados: 236
Tokens/seg aprox.: 7.508
```

Ventajas:
- respuesta más sobria;
- menos alucinación;
- respetó mejor el gate humano;
- no convirtió Serena en control de versiones ni Codex en gestor de proyectos.

Limitación:
- lento para operación diaria.

Uso recomendado:
```text
mistral-nemo:12b → síntesis académica local principal, metodología, análisis conceptual y revisión técnica.
```

### 3.4 `qwen2.5-coder:14b`

Prueba como generador de ticket para Codex: **condicionado**.

Problemas detectados:
- inventó comandos como `openclaw config show | grep "local-first"`;
- inventó `chatgpt status`;
- propuso ruta incorrecta `python V:\Sistema_Operativo_Tesis_Posgrado\build_all.py`;
- la ruta correcta observada y usada en la sesión es `python 07_scripts/build_all.py`;
- demasiado lento para tickets simples.

Métricas reportadas:
```text
Duración total: 243.292 s
Carga modelo: 46.413 s
Generación: 195.022 s
Tokens generados: 861
Tokens/s aprox.: 4.415
```

Uso recomendado:
```text
qwen2.5-coder:14b → tickets complejos de código bajo revisión humana; no usar para tickets simples.
```

---

## 4. Política resultante de modelos

```text
qwen3:4b              → comandos rápidos / Telegram / clasificación
qwen2.5:7b-instruct   → respuestas simples estructuradas y checklists
hermes3:8b            → borradores técnicos internos
mistral-nemo:12b      → síntesis académica local principal
qwen2.5-coder:14b     → código y tickets complejos para Codex, revisado
phi4:14b / qwen3:14b  → experimentales
```

Configuración recomendada:

```powershell
$env:OPENCLAW_CLOUD_ENABLED="0"
$env:OPENCLAW_CHATGPT_PLUS_ENABLED="0"
$env:OPENCLAW_WEB_ENABLED="0"
$env:OPENCLAW_EXTERNAL_ROUTER_ENABLED="0"

$env:OPENCLAW_EDGE_OLLAMA_BASE_URL="http://127.0.0.1:11434"
$env:OPENCLAW_PROVIDER_POLICY="hybrid_controlled"

$env:OPENCLAW_TELEGRAM_FALLBACK_MODEL="qwen3:4b"
$env:OPENCLAW_DESKTOP_RUNTIME_MODEL="mistral-nemo:12b"
```

---

## 5. Guardrails aprendidos

### 5.1 No automatizar ChatGPT web como dependencia crítica

El carril `chatgpt_plus_web_assisted` debe quedar:
- apagado por defecto;
- experimental;
- manual supervisado si se usa;
- nunca como requisito para operación del Sistema Operativo de Tesis.

### 5.2 Todo modelo local requiere prompt de sistema restrictivo

El comportamiento sin prompt de sistema produjo alucinaciones. El prompt restrictivo redujo errores, pero no los eliminó completamente.

### 5.3 Codex debe recibir tickets cerrados

Codex no debe operar con instrucciones abiertas. Debe recibir:
- objetivo;
- alcance;
- no-alcance;
- rutas permitidas;
- criterios de aceptación;
- comandos de validación;
- condiciones de paro;
- restricciones sobre secretos, canon y derivados.

### 5.4 Prohibiciones operativas

```text
No editar 06_dashboard/generado/ manualmente.
No editar runtime/openclaw/state/web_session_profile/.
No guardar cookies, tokens ni perfiles de navegador en Git.
No activar nube sin permiso explícito.
No usar modelos locales para conclusiones canónicas sin Serena/preflight y revisión humana.
No usar qwen2.5-coder:14b como generador final de comandos sin revisión.
```

---

## 6. Correcciones recomendadas al Sistema Operativo de Tesis

### 6.1 Incorporar una política formal de modelos

Crear o actualizar una política tipo:

```text
00_sistema_tesis/config/openclaw_model_policy.yaml
```

Contenido sugerido:
- perfil del modelo;
- uso permitido;
- uso prohibido;
- temperatura recomendada;
- top_p;
- riesgo;
- necesidad de Serena;
- necesidad de gate humano;
- estado: aprobado / condicionado / rechazado.

### 6.2 Integrar un evaluador de fidelidad contextual

Agregar pruebas que detecten automáticamente errores como:

```text
"OpenClaw aprueba automáticamente"
"Telegram comunica con comité asesor"
"Serena MCP es control de versiones"
"Codex es gestor de proyectos"
"OpenClaw edita código directamente"
"chatgpt status"
"openclaw config show"
```

### 6.3 Mejorar el generador de tickets

El sistema debe incluir una plantilla rígida de ticket para Codex, con validación de comandos permitidos.

### 6.4 Separar modos de ejecución

```text
modo_rapido     → qwen3:4b / qwen2.5:7b-instruct
modo_academico  → mistral-nemo:12b
modo_codigo     → qwen2.5-coder:14b
modo_experimental → phi4:14b / qwen3:14b
```

### 6.5 Agregar benchmark comparativo reproducible

El script PowerShell desarrollado durante la sesión debe integrarse como utilidad o plantilla de evaluación para generar:
- latencia;
- carga;
- tokens generados;
- tokens/s;
- evaluación manual;
- archivo Markdown;
- archivo JSON;
- clasificación de modelo.

---

## 7. Tareas propuestas para backlog

```text
T-051: Formalizar política de modelos locales de OpenClaw.
T-052: Crear suite de evaluación de fidelidad contextual para modelos locales.
T-053: Implementar plantilla canónica de ticket Codex local-first.
T-054: Desactivar ChatGPT web assisted por defecto y marcarlo como experimental.
T-055: Validar OpenClaw local-first con Ollama API aunque ollama CLI no esté en PATH.
T-056: Agregar reglas anti-comando-inventado para tickets generados por modelos.
T-057: Crear tabla comparativa de modelos locales con métricas y clasificación.
T-058: Integrar salida PET Toltecayotl al gestor de conocimiento y memoria derivada.
```

---

## 8. Decisión sugerida

**DEC propuesta:** `DEC-OPENCLAW-LOCALFIRST-MODEL-GOVERNANCE-20260501`

Resumen:
> Se adopta OpenClaw en modo local-first, con ChatGPT web assisted apagado por defecto, modelos locales evaluados mediante prompts restrictivos, Serena MCP como capa obligatoria de contexto/gobernanza en tareas sensibles, y Codex como ejecutor controlado por tickets, validadores y revisión humana.

Estado sugerido:
```text
propuesta_para_revision_humana
```

---

## 9. Conclusión epistémica

El conocimiento de esta sesión refuerza que el principal problema no es “tener modelos locales”, sino **gobernarlos**. Los modelos locales responden y son útiles, pero tienden a inventar funciones, comandos o garantías si no reciben contexto y restricciones explícitas. La mejora significativa del Sistema Operativo de Tesis debe centrarse en:

1. prompts de sistema estabilizados;
2. política formal de modelos;
3. validadores anti-alucinación contextual;
4. tickets rígidos para Codex;
5. separación estricta entre propuesta, ejecución, validación y aprobación humana;
6. operación local-first con nube apagada por defecto;
7. registro auditable de cada prueba, métrica y decisión.
